package com.example.jpmorgan.wihm_223;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.util.Log;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * Created by jpmorgan on 3/27/17.
 */


//Prim key UUID --> Firebase

public class User implements Serializable {

        private String uid, name, age, weight, length;
        private Context context;
        private String ip;
        private Date date;

    private BluetoothAdapter mBluetoothAdapter = null;
    private Sensor heartSen;
    private double heartRate = 0;
    private int lastX = 0;
    private double lastY = 0;
    public LineGraphSeries<DataPoint> series;

    private FirebaseDatabase mFirebaseDatabase;
    DatabaseReference ref;
    private DatabaseReference mFirebaseReference;

    Calendar c = Calendar.getInstance();
    SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
    String formattedDate = df.format(c.getTime());

    public User(){
        }

        public User(String uid, String name, String age, String weight, String length, Date date) {
            this.uid = uid; //Primaire key
            this.name = name;
            this.age = age;
            this.weight = weight;
            this.length = length;
            this.date = date;


            mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
            mFirebaseDatabase = FirebaseDatabase.getInstance();
            ref = mFirebaseDatabase.getReference("users");
            series = new LineGraphSeries<DataPoint>();
            // this.heartrates = heartrates;

        }
        //Connect
        public void Connect(Context context, String ip){
            this.context = context;
            this.ip = ip;

            BluetoothDevice newSen = mBluetoothAdapter.getRemoteDevice(ip);
            heartSen = new Sensor(newSen, context);
        }

        public double getHeartRate(){return heartRate; }

        public String getUid() {return uid;}

        public void setUid(String uid) {
            this.uid = uid;
        }

        public String getAge() {
            return age;
        }

        public void setAge(String age) {
            this.age = age;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getWeight() {
            return weight;
        }

        public void setWeight(String weight) {
            this.weight = weight;
        }

        public String getLength() {
            return length;
        }

        public void setLength(String length) {
            this.length = length;
        }

        public void setDate(Date date) { this.date = date; }
        public Date getDate() { return date; }


    private void getData() {

    }

    public void addEntry() {
        //lastY = RANDOM.nextDouble() * 100d;
        String heartB = heartSen.heartB;
        lastY = 0;
        int heartRate = 0;
        try {
            heartRate = Integer.parseInt(heartB);
            lastY = heartRate;
            Log.d("parsed int", String.valueOf(heartRate));
        } catch(NumberFormatException nfe) {
            System.out.println("Could not parse " + nfe);
        }
        //int hearRate = Integer.parseInt(heartB);
        //Log.d("parsed int", String.valueOf(hearRate));
        series.appendData(new DataPoint(lastX++, lastY), true, 100);
        //txtDisp1.setText(Double.toString(Math.round(lastY)));
        if (lastY>0){
            ref.child(getUid()).child(formattedDate).child("hartslag : " + lastX).setValue(lastY);
        }


    }

}
